import os,time
import cv2
import zipfile
import threading
import hashlib
import datetime
from flask import Flask, render_template, Response, request, jsonify, send_file

app = Flask(__name__) 

# Camera setup and configuration
camera_indexes = [0, 1, 2]
camera_lock = threading.Lock()

def initialize_camera():
        for index in camera_indexes:
            temp_camera = cv2.VideoCapture(index)
            if temp_camera.isOpened():
                print(temp_camera.isOpened())
                print(f"Camera opened successfully on index {index}")
                camera = temp_camera
                return camera
            else:
                print(f"Failed to open camera on index {index}")
                time.sleep(0.5)
                camera = None
                return camera
        

camera = initialize_camera()

if camera is None:
    print(camera)
    print("Failed to open any camera. Please check the camera connection and indexes.")
else:
    # Define the allowed resolutions
    resolutions = [(1280, 720)]

    # Set the default resolution
    camera.set(cv2.CAP_PROP_FRAME_WIDTH, resolutions[0][0])
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, resolutions[0][1])

    # Define the folder structure
    dataset_folder = "dataset"
    os.makedirs(dataset_folder, exist_ok=True)

    frame = None
    lock = threading.Lock()

    def capture_frames():
        global frame
        while True:
            with camera_lock:
                if camera is not None:
                    success, temp_frame = camera.read()
                    if success:
                        with lock:
                            frame = temp_frame

    # Start the frame capturing thread
    threading.Thread(target=capture_frames, daemon=True).start()

def gen_frames():
    global frame
    while True:
        with lock:
            if frame is None:
                continue
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

@app.route('/')
def index():
    if camera is None:
        return "1No camera available. Please check the camera connection and indexes."
    return render_template('index.html', resolutions=resolutions)

@app.route('/video_feed')
def video_feed():
    if camera is None:
        return "2No camera available. Please check the camera connection and indexes."
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/capture', methods=['POST'])
def capture():
    global camera
    if camera is None:
        return jsonify(success=False, message="3No camera available. Please check the camera connection and indexes.")

    # Get the selected resolution and class name
    resolution = request.form['resolution']
    class_name = request.form['class_name']

    # Set the camera resolution only if it has changed
    width, height = map(int, resolution.split('x'))
    with camera_lock:
        if camera.get(cv2.CAP_PROP_FRAME_WIDTH) != width or camera.get(cv2.CAP_PROP_FRAME_HEIGHT) != height:
            camera.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            camera.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

        # Capture and save the image
        ret, frame = camera.read()
    
    if not ret:
        return jsonify(success=False, message="Failed to capture image.")
    
    class_folder = os.path.join(dataset_folder, class_name)
    os.makedirs(class_folder, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    image_path = os.path.join(class_folder, f"{timestamp}.jpg")
    cv2.imwrite(image_path, frame)

    return jsonify(success=True, message="Image captured and saved successfully.")

@app.route('/browse')
def browse():
    # Get the list of class folders and images
    class_folders = [f for f in os.listdir(dataset_folder) if os.path.isdir(os.path.join(dataset_folder, f))]
    data = []
    for folder in class_folders:
        folder_path = os.path.join(dataset_folder, folder)
        images = [os.path.join(folder, img) for img in os.listdir(folder_path)]
        data.append((folder, images))

    return render_template('browse.html', data=data)

@app.route('/dataset/<path:filename>')
def dataset_files(filename):
    return send_file(os.path.join(dataset_folder, filename))

last_mod_time = None
dataset_hash = None

def get_dataset_hash():
    global dataset_hash, last_mod_time
    current_mod_time = max(os.path.getmtime(root) for root, _, _ in os.walk(dataset_folder))
    if last_mod_time != current_mod_time:
        hasher = hashlib.md5()
        for root, _, files in os.walk(dataset_folder):
            for file in files:
                with open(os.path.join(root, file), 'rb') as f:
                    hasher.update(f.read())
        dataset_hash = hasher.hexdigest()
        last_mod_time = current_mod_time
    return dataset_hash

@app.route('/download')
def download():
    now = datetime.datetime.now()
    formatted_date_time = now.strftime('%Y-%m-%d_%H-%M-%S')
    zip_filename = f"dataset_{formatted_date_time}.zip"
    if not os.path.exists(zip_filename) or get_dataset_hash() != dataset_hash:
        with zipfile.ZipFile(zip_filename, 'w') as zip_file:
            for root, _, files in os.walk(dataset_folder):
                for file in files:
                    zip_file.write(os.path.join(root, file))
    
    return send_file(zip_filename, as_attachment=True)

@app.route('/delete_image', methods=['GET','POST'])
def delete_image():
    data = request.get_json(force = True)
    print(data)
    if not data or 'image_paths' not in data:
        return jsonify(success=False, message="No image paths provided."), 400

    image_paths = data['image_paths']
    deleted_images = []
    folders_to_check = set()

    for image_path in image_paths:
        full_path = os.path.join('dataset', image_path)
        folder = os.path.dirname(full_path)
        folders_to_check.add(folder)  # Add the folder to the set
        if os.path.exists(full_path):
            os.remove(full_path)
            deleted_images.append(image_path)
        else:
            print(f"Image path not found: {full_path}")

    for folder in folders_to_check:
        if os.path.exists(folder) and not os.listdir(folder):
            try:
                os.rmdir(folder)
                print(f"Deleted empty folder: {folder}")
            except Exception as e:
                print(f"Error deleting folder {folder}: {str(e)}")

    return jsonify(success=True, message="Selected images and empty folders deleted successfully.")

    if deleted_images:
        return jsonify(success=True, message="Selected images deleted successfully.", deleted_images=deleted_images)
        
    else:
        return jsonify(success=False, message="No images were deleted.")


if __name__ == '__main__':
    app.run(host='192.168.137.220', port=5000, debug=False)

